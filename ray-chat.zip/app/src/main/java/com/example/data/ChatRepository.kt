package com.example.data

import kotlinx.coroutines.flow.Flow

class ChatRepository(private val chatDao: ChatDao) {
    fun getMessages(sessionId: String): Flow<List<ChatMessageEntity>> =
        chatDao.getMessagesBySession(sessionId)

    fun getAllSessions(): Flow<List<String>> =
        chatDao.getAllSessionIds()

    suspend fun addMessage(message: ChatMessageEntity): Long =
        chatDao.insertMessage(message)

    suspend fun clearSession(sessionId: String) =
        chatDao.clearSession(sessionId)

    suspend fun clearAll() =
        chatDao.clearAll()

    suspend fun getCount(sessionId: String): Int =
        chatDao.getMessageCount(sessionId)
}
