package com.example

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.lifecycle.viewmodel.compose.viewModel
import com.example.ui.ChatViewModel
import com.example.ui.MainChatScreen
import com.example.ui.theme.RAYCHATTheme

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            RAYCHATTheme {
                val chatViewModel: ChatViewModel = viewModel()
                MainChatScreen(viewModel = chatViewModel)
            }
        }
    }
}
