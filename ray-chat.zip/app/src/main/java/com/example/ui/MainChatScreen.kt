package com.example.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.asPaddingValues
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBars
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBars
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.AddPhotoAlternate
import androidx.compose.material.icons.filled.ArrowDropDown
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material.icons.filled.GraphicEq
import androidx.compose.material.icons.filled.Menu
import androidx.compose.material.icons.filled.Mic
import androidx.compose.material.icons.filled.MicNone
import androidx.compose.material.icons.filled.MoreVert
import androidx.compose.material.icons.filled.Send
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.layout.imePadding
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.DrawerValue
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.ModalNavigationDrawer
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.rememberDrawerState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.components.AiRespondingAnimation
import com.example.ui.components.AppNavigationDrawer
import com.example.ui.components.LiveVoiceScreen
import com.example.ui.components.MessageItemCard
import com.example.ui.components.ResetConfirmDialog
import com.example.ui.components.SettingsDialog
import com.example.ui.theme.DarkPillBg
import com.example.ui.theme.LiveOrbStart
import com.example.ui.theme.PureBlack
import com.example.ui.theme.TextPrimary
import com.example.ui.theme.TextSecondary
import kotlinx.coroutines.launch

@Composable
fun MainChatScreen(
    viewModel: ChatViewModel,
    modifier: Modifier = Modifier
) {
    val isLiveVoiceMode by viewModel.isLiveVoiceMode.collectAsState()
    val messages by viewModel.messages.collectAsState()
    val allSessions by viewModel.allSessions.collectAsState()
    val currentSessionId by viewModel.currentSessionId.collectAsState()
    val isProcessing by viewModel.isProcessing.collectAsState()
    val selectedPersona by viewModel.selectedPersona.collectAsState()
    val autoSpeak by viewModel.autoSpeakTts.collectAsState()
    val notificationsEnabled by viewModel.notificationsEnabled.collectAsState()
    val showSettingsDialog by viewModel.showSettingsDialog.collectAsState()
    val showResetDialog by viewModel.showResetDialog.collectAsState()

    val isSpeaking by viewModel.ttsManager.isSpeaking.collectAsState()
    val isListening by viewModel.voiceRecognizerManager.isListening.collectAsState()
    val rmsDb by viewModel.voiceRecognizerManager.rmsDb.collectAsState()
    val recognizedText by viewModel.voiceRecognizerManager.recognizedText.collectAsState()

    var inputText by remember { mutableStateOf("") }
    val listState = rememberLazyListState()
    val drawerState = rememberDrawerState(initialValue = DrawerValue.Closed)
    val coroutineScope = rememberCoroutineScope()

    var speechRate by remember { mutableStateOf(1.0f) }
    var pitch by remember { mutableStateOf(1.0f) }

    var isOcrProcessing by remember { mutableStateOf(false) }
    var pendingVoiceAction by remember { mutableStateOf<String?>(null) }
    val context = androidx.compose.ui.platform.LocalContext.current

    val micPermissionLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.RequestPermission()
    ) { isGranted ->
        if (isGranted) {
            when (pendingVoiceAction) {
                "live" -> viewModel.toggleLiveVoiceMode()
                "chat" -> viewModel.startVoiceInput { spokenText -> inputText = spokenText }
            }
        } else {
            android.widget.Toast.makeText(context, "Izin mikrofon diperlukan untuk input suara", android.widget.Toast.LENGTH_SHORT).show()
        }
        pendingVoiceAction = null
    }

    val imagePickerLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.GetContent()
    ) { uri ->
        uri?.let { imageUri ->
            isOcrProcessing = true
            coroutineScope.launch {
                val ocrResult = com.example.engine.ImageOcrManager.recognizeTextFromUri(context, imageUri)
                isOcrProcessing = false
                val prompt = "Teks Hasil OCR Gambar:\n$ocrResult\n\nTolong jelaskan dan jawab mengenai isi gambar atau teks di atas."
                viewModel.sendMessage(prompt)
            }
        }
    }

    // Auto scroll on new messages or when AI is responding
    LaunchedEffect(messages.size, isProcessing) {
        if (isProcessing) {
            val targetIndex = if (messages.isNotEmpty()) messages.size else 0
            listState.animateScrollToItem(targetIndex)
        } else if (messages.isNotEmpty()) {
            listState.animateScrollToItem(messages.size - 1)
        }
    }

    // Live Voice Fullscreen View
    if (isLiveVoiceMode) {
        LiveVoiceScreen(
            isListening = isListening,
            isSpeaking = isSpeaking,
            isProcessing = isProcessing,
            rmsDb = rmsDb,
            latestText = recognizedText.ifBlank { messages.lastOrNull()?.content ?: "" },
            onMicClick = {
                if (isListening) {
                    viewModel.voiceRecognizerManager.stopListening()
                } else {
                    viewModel.startLiveVoiceListening()
                }
            },
            onCloseClick = { viewModel.toggleLiveVoiceMode() },
            onOpenDrawer = { coroutineScope.launch { drawerState.open() } },
            onOpenSettings = { viewModel.toggleSettingsDialog(true) }
        )
        return
    }

    // Main Chat View with Side Navigation Drawer
    ModalNavigationDrawer(
        drawerState = drawerState,
        drawerContent = {
            AppNavigationDrawer(
                sessions = allSessions,
                currentSessionId = currentSessionId,
                onNewChatClick = { viewModel.createNewSession() },
                onSelectSession = { viewModel.selectSession(it) },
                onDeleteSession = { viewModel.deleteSession(it) },
                onResetAiClick = { viewModel.toggleResetDialog(true) },
                onSettingsClick = { viewModel.toggleSettingsDialog(true) },
                onCloseDrawer = { coroutineScope.launch { drawerState.close() } }
            )
        }
    ) {
        Scaffold(
            modifier = modifier.fillMaxSize(),
            containerColor = PureBlack,
            topBar = {
                // Top Header Bar (Matches Screenshot #1)
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .background(PureBlack)
                        .padding(WindowInsets.statusBars.asPaddingValues())
                        .padding(horizontal = 12.dp, vertical = 8.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    // Menu Drawer Toggle
                    IconButton(
                        onClick = { coroutineScope.launch { drawerState.open() } },
                        modifier = Modifier.testTag("open_drawer_button")
                    ) {
                        Icon(
                            imageVector = Icons.Default.Menu,
                            contentDescription = "Buka Drawer",
                            tint = TextPrimary
                        )
                    }

                    // Model Selector Dropdown
                    Row(
                        modifier = Modifier
                            .clip(RoundedCornerShape(20.dp))
                            .clickable { viewModel.toggleSettingsDialog(true) }
                            .padding(horizontal = 10.dp, vertical = 6.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = if (selectedPersona == "rudi") "Mode Santai" else "Mode Executive",
                            style = MaterialTheme.typography.titleMedium,
                            fontWeight = FontWeight.Bold,
                            color = TextPrimary
                        )
                        Spacer(modifier = Modifier.width(4.dp))
                        Icon(
                            imageVector = Icons.Default.ArrowDropDown,
                            contentDescription = "Pilih Model",
                            tint = TextPrimary
                        )
                    }

                    // Action Icons: New Chat & Overflow
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        // New Chat Button
                        IconButton(
                            onClick = { viewModel.createNewSession() },
                            modifier = Modifier.testTag("new_chat_top_button")
                        ) {
                            Icon(
                                imageVector = Icons.Default.Edit,
                                contentDescription = "Percakapan Baru",
                                tint = TextPrimary
                            )
                        }

                        // More Options
                        IconButton(
                            onClick = { viewModel.toggleSettingsDialog(true) },
                            modifier = Modifier.testTag("top_menu_overflow")
                        ) {
                            Icon(
                                imageVector = Icons.Default.MoreVert,
                                contentDescription = "Opsi",
                                tint = TextPrimary
                            )
                        }
                    }
                }
            },
            bottomBar = {
                // Bottom Input Control Bar (Matches Screenshot #1, with IME Keyboard elevation)
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .background(PureBlack)
                        .navigationBarsPadding()
                        .imePadding()
                        .padding(horizontal = 12.dp, vertical = 8.dp),
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    // AI Disclaimer (Matches Screenshot #1)
                    Text(
                        text = if (isListening) "Sedang mendengarkan... Lepas tombol mikrofon untuk mengirim." else "RAY-CHAT adalah AI dan dapat melakukan kesalahan.",
                        fontSize = 12.sp,
                        color = if (isListening) Color.Red else TextSecondary,
                        modifier = Modifier.padding(bottom = 10.dp)
                    )

                    // Input Pill Container
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clip(RoundedCornerShape(32.dp))
                            .background(DarkPillBg)
                            .padding(horizontal = 12.dp, vertical = 4.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        // Text Field
                        OutlinedTextField(
                            value = inputText,
                            onValueChange = { inputText = it },
                            modifier = Modifier
                                .weight(1f)
                                .testTag("chat_input_field"),
                            placeholder = {
                                Text(
                                    text = if (isListening) "Mendengarkan suara..." else "Minta RAY-CHAT...",
                                    fontSize = 15.sp,
                                    color = if (isListening) Color.Red else TextSecondary
                                )
                            },
                            colors = OutlinedTextFieldDefaults.colors(
                                focusedContainerColor = Color.Transparent,
                                unfocusedContainerColor = Color.Transparent,
                                focusedBorderColor = Color.Transparent,
                                unfocusedBorderColor = Color.Transparent,
                                focusedTextColor = TextPrimary,
                                unfocusedTextColor = TextPrimary
                            ),
                            maxLines = 3
                        )

                        // Photo Upload OCR Button
                        IconButton(
                            onClick = { imagePickerLauncher.launch("image/*") },
                            modifier = Modifier
                                .size(40.dp)
                                .testTag("upload_image_ocr_button")
                        ) {
                            if (isOcrProcessing) {
                                CircularProgressIndicator(
                                    modifier = Modifier.size(18.dp),
                                    color = LiveOrbStart,
                                    strokeWidth = 2.dp
                                )
                            } else {
                                Icon(
                                    imageVector = Icons.Default.AddPhotoAlternate,
                                    contentDescription = "Upload Foto (OCR)",
                                    tint = TextPrimary,
                                    modifier = Modifier.size(22.dp)
                                )
                            }
                        }

                        // Voice Mic Button (Hold-To-Talk: Press & hold to speak, release to send)
                        Box(
                            modifier = Modifier
                                .size(40.dp)
                                .clip(CircleShape)
                                .background(if (isListening) Color.Red.copy(alpha = 0.25f) else Color.Transparent)
                                .pointerInput(Unit) {
                                    detectTapGestures(
                                        onPress = {
                                            val hasMicPermission = androidx.core.content.ContextCompat.checkSelfPermission(
                                                context,
                                                android.Manifest.permission.RECORD_AUDIO
                                            ) == android.content.pm.PackageManager.PERMISSION_GRANTED

                                            if (hasMicPermission) {
                                                viewModel.startVoiceInput { spokenText ->
                                                    inputText = spokenText
                                                }
                                                try {
                                                    awaitRelease()
                                                } finally {
                                                    viewModel.voiceRecognizerManager.stopListening()
                                                }
                                            } else {
                                                pendingVoiceAction = "chat"
                                                micPermissionLauncher.launch(android.Manifest.permission.RECORD_AUDIO)
                                            }
                                        }
                                    )
                                }
                                .testTag("voice_input_button"),
                            contentAlignment = Alignment.Center
                        ) {
                            Icon(
                                imageVector = if (isListening) Icons.Default.Mic else Icons.Default.MicNone,
                                contentDescription = "Tekan dan tahan untuk bicara",
                                tint = if (isListening) Color.Red else TextPrimary,
                                modifier = Modifier.size(22.dp)
                            )
                        }

                        // Send OR Live Voice Orb Mode Toggle Button
                        if (inputText.isNotBlank()) {
                            IconButton(
                                onClick = {
                                    if (inputText.isNotBlank() && !isProcessing) {
                                        val query = inputText
                                        inputText = ""
                                        viewModel.sendMessage(query)
                                    }
                                },
                                modifier = Modifier
                                    .size(40.dp)
                                    .clip(CircleShape)
                                    .background(TextPrimary)
                                    .testTag("send_button")
                            ) {
                                if (isProcessing) {
                                    CircularProgressIndicator(
                                        modifier = Modifier.size(18.dp),
                                        color = PureBlack,
                                        strokeWidth = 2.dp
                                    )
                                } else {
                                    Icon(
                                        imageVector = Icons.Default.Send,
                                        contentDescription = "Kirim",
                                        tint = PureBlack,
                                        modifier = Modifier.size(18.dp)
                                    )
                                }
                            }
                        } else {
                            // Live Voice Orb Toggle Button (Waveform icon pill like Screenshot #1)
                            IconButton(
                                onClick = {
                                    val hasMicPermission = androidx.core.content.ContextCompat.checkSelfPermission(
                                        context,
                                        android.Manifest.permission.RECORD_AUDIO
                                    ) == android.content.pm.PackageManager.PERMISSION_GRANTED

                                    if (hasMicPermission) {
                                        viewModel.toggleLiveVoiceMode()
                                    } else {
                                        pendingVoiceAction = "live"
                                        micPermissionLauncher.launch(android.Manifest.permission.RECORD_AUDIO)
                                    }
                                },
                                modifier = Modifier
                                    .size(40.dp)
                                    .clip(CircleShape)
                                    .background(LiveOrbStart)
                                    .testTag("live_orb_toggle_button")
                            ) {
                                Icon(
                                    imageVector = Icons.Default.GraphicEq,
                                    contentDescription = "Live Voice Mode",
                                    tint = PureBlack,
                                    modifier = Modifier.size(22.dp)
                                )
                            }
                        }
                    }
                }
            }
        ) { innerPadding ->
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(innerPadding)
                    .background(PureBlack)
            ) {
                // Messages List
                LazyColumn(
                    state = listState,
                    modifier = Modifier.fillMaxSize()
                ) {
                    items(
                        items = messages,
                        key = { it.id }
                    ) { message ->
                        MessageItemCard(
                            message = message,
                            onSpeak = { text -> viewModel.speakText(text) },
                            onCopy = { text -> viewModel.copyToClipboard(text) },
                            onRegenerate = { viewModel.sendMessage(message.content) }
                        )
                    }

                    if (isProcessing) {
                        item(key = "ai_responding_indicator") {
                            AiRespondingAnimation()
                        }
                    }
                }
            }
        }
    }

    // Fullscreen Settings Page
    if (showSettingsDialog) {
        SettingsScreen(
            selectedPersona = selectedPersona,
            onPersonaChange = { viewModel.setPersona(it) },
            autoSpeak = autoSpeak,
            onAutoSpeakChange = { viewModel.toggleAutoSpeak() },
            notificationsEnabled = notificationsEnabled,
            onNotificationChange = { viewModel.toggleNotifications() },
            speechRate = speechRate,
            onSpeechRateChange = {
                speechRate = it
                viewModel.ttsManager.speechRate = it
            },
            pitch = pitch,
            onPitchChange = {
                pitch = it
                viewModel.ttsManager.pitch = it
            },
            onResetCurrentChat = { viewModel.resetChat() },
            onBackClick = { viewModel.toggleSettingsDialog(false) }
        )
        return
    }

    // Reset Confirmation Dialog
    if (showResetDialog) {
        ResetConfirmDialog(
            onConfirmReset = { viewModel.resetChat() },
            onDismiss = { viewModel.toggleResetDialog(false) }
        )
    }
}

