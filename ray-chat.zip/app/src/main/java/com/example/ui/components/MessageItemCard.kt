package com.example.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ContentCopy
import androidx.compose.material.icons.filled.MoreHoriz
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.ThumbDownOffAlt
import androidx.compose.material.icons.filled.ThumbUpOffAlt
import androidx.compose.material.icons.filled.VolumeUp
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.ChatMessageEntity
import com.example.ui.theme.DarkPillBg
import com.example.ui.theme.TextPrimary
import com.example.ui.theme.TextSecondary
import com.example.ui.theme.UserBubbleBg

@Composable
fun MessageItemCard(
    message: ChatMessageEntity,
    onSpeak: (String) -> Unit,
    onCopy: (String) -> Unit,
    onRegenerate: () -> Unit = {},
    modifier: Modifier = Modifier
) {
    val isUser = message.sender == "user"
    var isLiked by remember { mutableStateOf<Boolean?>(null) }

    Column(
        modifier = modifier
            .fillMaxWidth()
            .padding(vertical = 10.dp, horizontal = 16.dp),
        horizontalAlignment = if (isUser) Alignment.End else Alignment.Start
    ) {
        if (isUser) {
            // User Message Pill (Matches Screenshot #1)
            Box(
                modifier = Modifier
                    .clip(RoundedCornerShape(24.dp))
                    .background(UserBubbleBg)
                    .padding(horizontal = 20.dp, vertical = 12.dp)
                    .testTag("user_message_bubble")
            ) {
                Text(
                    text = message.content,
                    color = TextPrimary,
                    style = MaterialTheme.typography.bodyLarge,
                    fontSize = 16.sp
                )
            }
        } else {
            // AI Response (Clean Minimal Text like Screenshot #1)
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .testTag("assistant_message_card")
            ) {
                // Parse and render text/code blocks
                val parsedChunks = parseContentWithCode(message.content)
                parsedChunks.forEach { chunk ->
                    when (chunk) {
                        is ParsedChunk.Text -> {
                            // Check for markdown image format ![alt](url)
                            val imgRegex = Regex("!\\[(.*?)\\]\\((.*?)\\)")
                            val matches = imgRegex.findAll(chunk.content).toList()

                            if (matches.isNotEmpty()) {
                                var lastIdx = 0
                                matches.forEach { match ->
                                    val textBefore = chunk.content.substring(lastIdx, match.range.first).trim()
                                    if (textBefore.isNotBlank()) {
                                        Text(
                                            text = textBefore,
                                            color = TextPrimary,
                                            style = MaterialTheme.typography.bodyLarge,
                                            fontSize = 16.sp,
                                            lineHeight = 24.sp
                                        )
                                    }
                                    val imageUrl = match.groupValues.getOrNull(2) ?: ""
                                    if (imageUrl.isNotBlank()) {
                                        Spacer(modifier = Modifier.height(8.dp))
                                        val context = androidx.compose.ui.platform.LocalContext.current
                                        Row(
                                            modifier = Modifier
                                                .fillMaxWidth()
                                                .clip(RoundedCornerShape(16.dp))
                                                .background(DarkPillBg)
                                                .clickable {
                                                    val intent = android.content.Intent(android.content.Intent.ACTION_VIEW, android.net.Uri.parse(imageUrl))
                                                    context.startActivity(intent)
                                                }
                                                .padding(14.dp),
                                            verticalAlignment = Alignment.CenterVertically,
                                            horizontalArrangement = Arrangement.SpaceBetween
                                        ) {
                                            Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.weight(1f)) {
                                                Icon(
                                                    imageVector = Icons.Default.MoreHoriz,
                                                    contentDescription = "Gambar AI",
                                                    tint = com.example.ui.theme.LiveOrbStart
                                                )
                                                Spacer(modifier = Modifier.width(8.dp))
                                                Text(
                                                    text = "🖼️ Klik untuk Buka/Download Gambar AI",
                                                    color = com.example.ui.theme.LiveOrbStart,
                                                    fontWeight = androidx.compose.ui.text.font.FontWeight.Bold,
                                                    fontSize = 14.sp
                                                )
                                            }
                                            Icon(
                                                imageVector = Icons.Default.ContentCopy,
                                                contentDescription = "Download",
                                                tint = TextPrimary
                                            )
                                        }
                                        Spacer(modifier = Modifier.height(8.dp))
                                    }
                                    lastIdx = match.range.last + 1
                                }
                                if (lastIdx < chunk.content.length) {
                                    val remainingText = chunk.content.substring(lastIdx).trim()
                                    if (remainingText.isNotBlank()) {
                                        Text(
                                            text = remainingText,
                                            color = TextPrimary,
                                            style = MaterialTheme.typography.bodyLarge,
                                            fontSize = 16.sp,
                                            lineHeight = 24.sp
                                        )
                                    }
                                }
                            } else {
                                Text(
                                    text = chunk.content,
                                    color = TextPrimary,
                                    style = MaterialTheme.typography.bodyLarge,
                                    fontSize = 16.sp,
                                    lineHeight = 24.sp
                                )
                            }
                        }
                        is ParsedChunk.Code -> {
                            CodeBlockCard(
                                language = chunk.language,
                                codeContent = chunk.code,
                                onCopy = onCopy
                            )
                        }
                    }
                }

                Spacer(modifier = Modifier.height(10.dp))

                // Action Bar underneath AI response (Matches Screenshot #1)
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.Start,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    // Thumbs Up
                    IconButton(
                        onClick = { isLiked = if (isLiked == true) null else true },
                        modifier = Modifier.size(36.dp)
                    ) {
                        Icon(
                            imageVector = Icons.Default.ThumbUpOffAlt,
                            contentDescription = "Suka",
                            tint = if (isLiked == true) TextPrimary else TextSecondary,
                            modifier = Modifier.size(20.dp)
                        )
                    }

                    // Thumbs Down
                    IconButton(
                        onClick = { isLiked = if (isLiked == false) null else false },
                        modifier = Modifier.size(36.dp)
                    ) {
                        Icon(
                            imageVector = Icons.Default.ThumbDownOffAlt,
                            contentDescription = "Tidak Suka",
                            tint = if (isLiked == false) TextPrimary else TextSecondary,
                            modifier = Modifier.size(20.dp)
                        )
                    }

                    // Regenerate Response
                    IconButton(
                        onClick = onRegenerate,
                        modifier = Modifier.size(36.dp)
                    ) {
                        Icon(
                            imageVector = Icons.Default.Refresh,
                            contentDescription = "Buat Ulang",
                            tint = TextSecondary,
                            modifier = Modifier.size(20.dp)
                        )
                    }

                    // Copy Text
                    IconButton(
                        onClick = { onCopy(message.content) },
                        modifier = Modifier.size(36.dp)
                    ) {
                        Icon(
                            imageVector = Icons.Default.ContentCopy,
                            contentDescription = "Salin",
                            tint = TextSecondary,
                            modifier = Modifier.size(20.dp)
                        )
                    }

                    // More Options
                    IconButton(
                        onClick = { },
                        modifier = Modifier.size(36.dp)
                    ) {
                        Icon(
                            imageVector = Icons.Default.MoreHoriz,
                            contentDescription = "Lainnya",
                            tint = TextSecondary,
                            modifier = Modifier.size(20.dp)
                        )
                    }

                    Spacer(modifier = Modifier.weight(1f))

                    // Voice Speaker TTS Icon
                    IconButton(
                        onClick = { onSpeak(message.content) },
                        modifier = Modifier.size(36.dp)
                    ) {
                        Icon(
                            imageVector = Icons.Default.VolumeUp,
                            contentDescription = "Bacakan Suara",
                            tint = TextPrimary,
                            modifier = Modifier.size(22.dp)
                        )
                    }
                }
            }
        }
    }
}

sealed class ParsedChunk {
    data class Text(val content: String) : ParsedChunk()
    data class Code(val language: String, val code: String) : ParsedChunk()
}

fun parseContentWithCode(rawText: String): List<ParsedChunk> {
    val list = mutableListOf<ParsedChunk>()
    val regex = Regex("```(\\w*)\\n?([\\s\\S]*?)```")
    var currentIndex = 0

    regex.findAll(rawText).forEach { matchResult ->
        val range = matchResult.range
        if (range.first > currentIndex) {
            val textPart = rawText.substring(currentIndex, range.first).trim()
            if (textPart.isNotBlank()) {
                list.add(ParsedChunk.Text(textPart))
            }
        }
        val lang = matchResult.groupValues.getOrNull(1) ?: "code"
        val codeBody = matchResult.groupValues.getOrNull(2) ?: ""
        list.add(ParsedChunk.Code(lang, codeBody))
        currentIndex = range.last + 1
    }

    if (currentIndex < rawText.length) {
        val remaining = rawText.substring(currentIndex).trim()
        if (remaining.isNotBlank()) {
            list.add(ParsedChunk.Text(remaining))
        }
    }

    if (list.isEmpty()) {
        list.add(ParsedChunk.Text(rawText))
    }

    return list
}
