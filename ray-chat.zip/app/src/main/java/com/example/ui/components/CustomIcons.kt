package com.example.ui.components

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.layout.size
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.PathFillType
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.unit.dp

@Composable
fun WhatsAppLogo(
    modifier: Modifier = Modifier.size(22.dp),
    tint: Color = Color.White
) {
    Canvas(modifier = modifier) {
        val w = size.width
        val h = size.height

        // Outer speech bubble / circle
        val path = Path().apply {
            fillType = PathFillType.NonZero
            moveTo(w * 0.5f, h * 0.08f)
            cubicTo(w * 0.27f, h * 0.08f, w * 0.08f, h * 0.27f, w * 0.08f, h * 0.5f)
            cubicTo(w * 0.08f, h * 0.58f, w * 0.10f, h * 0.65f, w * 0.14f, h * 0.71f)
            lineTo(w * 0.08f, h * 0.92f)
            lineTo(w * 0.29f, h * 0.86f)
            cubicTo(w * 0.35f, h * 0.90f, w * 0.43f, h * 0.92f, w * 0.50f, h * 0.92f)
            cubicTo(w * 0.73f, h * 0.92f, w * 0.92f, h * 0.73f, w * 0.92f, h * 0.50f)
            cubicTo(w * 0.92f, h * 0.27f, w * 0.73f, h * 0.08f, w * 0.50f, h * 0.08f)
            close()
        }

        drawPath(path = path, color = tint, style = Stroke(width = w * 0.08f))

        // Inner phone handset
        val phonePath = Path().apply {
            moveTo(w * 0.35f, h * 0.35f)
            cubicTo(w * 0.35f, h * 0.50f, w * 0.50f, h * 0.65f, w * 0.65f, h * 0.65f)
            lineTo(w * 0.72f, h * 0.58f)
            lineTo(w * 0.62f, h * 0.48f)
            lineTo(w * 0.55f, h * 0.52f)
            cubicTo(w * 0.48f, h * 0.48f, w * 0.45f, h * 0.45f, w * 0.42f, h * 0.38f)
            lineTo(w * 0.46f, h * 0.31f)
            lineTo(w * 0.36f, h * 0.21f)
            close()
        }
        drawPath(path = phonePath, color = tint)
    }
}

@Composable
fun TikTokLogo(
    modifier: Modifier = Modifier.size(22.dp),
    tint: Color = Color.White
) {
    Canvas(modifier = modifier) {
        val w = size.width
        val h = size.height

        val path = Path().apply {
            moveTo(w * 0.80f, h * 0.28f)
            cubicTo(w * 0.75f, h * 0.28f, w * 0.70f, h * 0.25f, w * 0.65f, h * 0.20f)
            lineTo(w * 0.65f, h * 0.08f)
            lineTo(w * 0.50f, h * 0.08f)
            lineTo(w * 0.50f, h * 0.65f)
            cubicTo(w * 0.50f, h * 0.72f, w * 0.45f, h * 0.78f, w * 0.38f, h * 0.78f)
            cubicTo(w * 0.31f, h * 0.78f, w * 0.25f, h * 0.72f, w * 0.25f, h * 0.65f)
            cubicTo(w * 0.25f, h * 0.58f, w * 0.31f, h * 0.52f, w * 0.38f, h * 0.52f)
            lineTo(w * 0.38f, h * 0.38f)
            cubicTo(w * 0.23f, h * 0.38f, w * 0.10f, h * 0.50f, w * 0.10f, h * 0.65f)
            cubicTo(w * 0.10f, h * 0.80f, w * 0.23f, h * 0.92f, w * 0.38f, h * 0.92f)
            cubicTo(w * 0.53f, h * 0.92f, w * 0.65f, h * 0.80f, w * 0.65f, h * 0.65f)
            lineTo(w * 0.65f, h * 0.38f)
            cubicTo(w * 0.72f, h * 0.42f, w * 0.80f, h * 0.44f, w * 0.88f, h * 0.44f)
            lineTo(w * 0.88f, h * 0.28f)
            close()
        }

        drawPath(path = path, color = tint)
    }
}
