package com.example.ui.components

import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.asPaddingValues
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBars
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBars
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Menu
import androidx.compose.material.icons.filled.Mic
import androidx.compose.material.icons.filled.MicNone
import androidx.compose.material.icons.filled.Tune
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.blur
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.scale
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.theme.DarkPillBg
import com.example.ui.theme.ElectricViolet
import com.example.ui.theme.LiveOrbEnd
import com.example.ui.theme.LiveOrbGlow
import com.example.ui.theme.LiveOrbStart
import com.example.ui.theme.NeonCyan
import com.example.ui.theme.PureBlack
import com.example.ui.theme.TextPrimary
import com.example.ui.theme.TextSecondary

@Composable
fun LiveVoiceScreen(
    isListening: Boolean,
    isSpeaking: Boolean,
    isProcessing: Boolean,
    rmsDb: Float,
    latestText: String,
    onMicClick: () -> Unit,
    onCloseClick: () -> Unit,
    onOpenDrawer: () -> Unit,
    onOpenSettings: () -> Unit,
    modifier: Modifier = Modifier
) {
    // Dynamic pulsing calculation based on speech pitch/volume and speech state
    val basePulseTransition = rememberInfiniteTransition(label = "pulse_transition")
    val idlePulse by basePulseTransition.animateFloat(
        initialValue = 0.92f,
        targetValue = 1.08f,
        animationSpec = infiniteRepeatable(
            animation = tween(1200, easing = FastOutSlowInEasing),
            repeatMode = RepeatMode.Reverse
        ),
        label = "idle_pulse"
    )

    // Dynamic scale calculated from real-time microphone volume or speaking status
    val voiceScaleTarget = when {
        isSpeaking -> 1.35f + (idlePulse * 0.15f)
        isListening -> 1.0f + (rmsDb.coerceIn(0f, 15f) / 10f)
        isProcessing -> 1.15f
        else -> idlePulse
    }

    val animatedScale by animateFloatAsState(
        targetValue = voiceScaleTarget,
        animationSpec = tween(durationMillis = 180),
        label = "orb_scale_anim"
    )

    Column(
        modifier = modifier
            .fillMaxSize()
            .background(PureBlack)
    ) {
        // Top Navigation Header
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(WindowInsets.statusBars.asPaddingValues())
                .padding(horizontal = 16.dp, vertical = 12.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            IconButton(
                onClick = onOpenDrawer,
                modifier = Modifier.testTag("live_drawer_menu")
            ) {
                Icon(
                    imageVector = Icons.Default.Menu,
                    contentDescription = "Menu",
                    tint = TextPrimary
                )
            }

            // Live Mode Pill Badge
            Box(
                modifier = Modifier
                    .clip(RoundedCornerShape(20.dp))
                    .background(DarkPillBg)
                    .padding(horizontal = 16.dp, vertical = 6.dp)
            ) {
                Text(
                    text = "Live Voice Mode",
                    style = MaterialTheme.typography.titleMedium,
                    color = TextPrimary,
                    fontWeight = FontWeight.SemiBold
                )
            }

            IconButton(
                onClick = onOpenSettings,
                modifier = Modifier.testTag("live_settings")
            ) {
                Icon(
                    imageVector = Icons.Default.Tune,
                    contentDescription = "Pengaturan",
                    tint = TextPrimary
                )
            }
        }

        // Center Voice Pulsing Orb
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .weight(1f),
            contentAlignment = Alignment.Center
        ) {
            Column(
                modifier = Modifier.padding(horizontal = 24.dp),
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.Center
            ) {
                Box(
                    contentAlignment = Alignment.Center,
                    modifier = Modifier.size(280.dp)
                ) {
                    // Outer Glow Layer
                    Box(
                        modifier = Modifier
                            .size(260.dp)
                            .scale(animatedScale * 1.15f)
                            .clip(CircleShape)
                            .background(
                                Brush.radialGradient(
                                    colors = listOf(LiveOrbGlow.copy(alpha = 0.5f), Color.Transparent)
                                )
                            )
                    )

                    // Main Organic Audio Orb Circle
                    Box(
                        modifier = Modifier
                            .size(200.dp)
                            .scale(animatedScale)
                            .clip(CircleShape)
                            .background(
                                Brush.linearGradient(
                                    listOf(LiveOrbStart, LiveOrbEnd, ElectricViolet)
                                )
                            )
                            .clickable { onMicClick() }
                            .testTag("center_voice_orb_button")
                    )
                }

                Spacer(modifier = Modifier.height(32.dp))

                // Subtitle / Spoken Status Text
                Text(
                    text = when {
                        isSpeaking -> "RAY-CHAT Sedang Menjawab..."
                        isListening -> "Mendengarkan Suara..."
                        isProcessing -> "Memproses Respon Suara..."
                        else -> "Ketuk mikrofon untuk mulai bicara"
                    },
                    style = MaterialTheme.typography.titleMedium,
                    color = TextSecondary,
                    fontWeight = FontWeight.Medium
                )

                if (latestText.isNotBlank()) {
                    Spacer(modifier = Modifier.height(12.dp))
                    Text(
                        text = "\"$latestText\"",
                        style = MaterialTheme.typography.bodyLarge,
                        color = TextPrimary,
                        modifier = Modifier.padding(horizontal = 20.dp)
                    )
                }
            }
        }

        // Bottom Controls Bar (Match Screenshot #3)
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(WindowInsets.navigationBars.asPaddingValues())
                .padding(horizontal = 16.dp, vertical = 20.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            // Pill input background
            Box(
                modifier = Modifier
                    .weight(1f)
                    .clip(RoundedCornerShape(30.dp))
                    .background(DarkPillBg)
                    .clickable { onCloseClick() }
                    .padding(horizontal = 20.dp, vertical = 14.dp)
            ) {
                Text(
                    text = "Buka Tampilan Chat Teks...",
                    color = TextSecondary,
                    fontSize = 15.sp
                )
            }

            Spacer(modifier = Modifier.width(12.dp))

            // Mic Button
            IconButton(
                onClick = onMicClick,
                modifier = Modifier
                    .size(54.dp)
                    .clip(CircleShape)
                    .background(if (isListening) ElectricViolet else DarkPillBg)
                    .testTag("live_mic_toggle")
            ) {
                Icon(
                    imageVector = if (isListening) Icons.Default.Mic else Icons.Default.MicNone,
                    contentDescription = "Mikrofon Suara",
                    tint = if (isListening) Color.White else TextPrimary,
                    modifier = Modifier.size(26.dp)
                )
            }

            Spacer(modifier = Modifier.width(12.dp))

            // Close Live Mode Button
            IconButton(
                onClick = onCloseClick,
                modifier = Modifier
                    .size(54.dp)
                    .clip(CircleShape)
                    .background(DarkPillBg)
                    .testTag("close_live_mode")
            ) {
                Icon(
                    imageVector = Icons.Default.Close,
                    contentDescription = "Tutup Live Mode",
                    tint = TextPrimary,
                    modifier = Modifier.size(26.dp)
                )
            }
        }
    }
}
