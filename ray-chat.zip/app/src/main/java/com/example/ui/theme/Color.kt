package com.example.ui.theme

import androidx.compose.ui.graphics.Color

val PureBlack = Color(0xFF000000)
val DarkPillBg = Color(0xFF1F2026)
val UserBubbleBg = Color(0xFF282A32)
val BorderSubtle = Color(0xFF2F313B)

val CardBorder = BorderSubtle
val DarkSlate = PureBlack
val ObsidianBlack = PureBlack
val CardSurface = DarkPillBg

val LiveOrbStart = Color(0xFF628EFF)
val LiveOrbEnd = Color(0xFF91B4FF)
val LiveOrbGlow = Color(0xFF3860FF)

val TextPrimary = Color(0xFFFFFFFF)
val TextSecondary = Color(0xFF9AA0A6)
val TextMuted = Color(0xFF5F6368)

val NeonCyan = Color(0xFF80D8FF)
val ElectricViolet = Color(0xFFB388FF)
val GlowEmerald = Color(0xFFB9F6CA)
val CyberMagenta = Color(0xFFFF80AB)

