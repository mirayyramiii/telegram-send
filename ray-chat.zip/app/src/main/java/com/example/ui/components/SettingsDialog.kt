package com.example.ui.components

import android.content.Intent
import android.net.Uri
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.OpenInNew
import androidx.compose.material.icons.filled.Psychology
import androidx.compose.material.icons.filled.RecordVoiceOver
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.RadioButton
import androidx.compose.material3.RadioButtonDefaults
import androidx.compose.material3.Slider
import androidx.compose.material3.SliderDefaults
import androidx.compose.material3.Switch
import androidx.compose.material3.SwitchDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.theme.PureBlack
import com.example.ui.theme.TextSecondary

@Composable
fun SettingsDialog(
    selectedPersona: String,
    onPersonaChange: (String) -> Unit,
    autoSpeak: Boolean,
    onAutoSpeakChange: () -> Unit,
    notificationsEnabled: Boolean,
    onNotificationChange: () -> Unit,
    speechRate: Float,
    onSpeechRateChange: (Float) -> Unit,
    pitch: Float,
    onPitchChange: (Float) -> Unit,
    onDismiss: () -> Unit
) {
    val context = LocalContext.current
    val scrollState = rememberScrollState()

    AlertDialog(
        onDismissRequest = onDismiss,
        title = {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween,
                modifier = Modifier.fillMaxWidth()
            ) {
                Text(
                    text = "Pengaturan RAY-CHAT",
                    style = MaterialTheme.typography.titleLarge,
                    fontWeight = FontWeight.Bold,
                    color = Color.White
                )
            }
        },
        text = {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .verticalScroll(scrollState)
                    .padding(vertical = 4.dp)
            ) {
                // Section 1: AI Model Persona
                SettingsSectionHeader(
                    icon = Icons.Default.Psychology,
                    title = "Mode Persona AI"
                )

                Spacer(modifier = Modifier.height(10.dp))

                // Option 1
                PersonaOptionCard(
                    title = "Mode Santai Gaul",
                    description = "Respon santai gaul lugas dengan data pencarian realtime DDG",
                    isSelected = selectedPersona == "rudi",
                    onClick = { onPersonaChange("rudi") }
                )

                Spacer(modifier = Modifier.height(8.dp))

                // Option 2
                PersonaOptionCard(
                    title = "Mode Executive AI",
                    description = "Respon formal profesional futuristik elegan dan presisi tinggi",
                    isSelected = selectedPersona == "ray",
                    onClick = { onPersonaChange("ray") }
                )

                Spacer(modifier = Modifier.height(18.dp))
                HorizontalDivider(color = Color.White.copy(alpha = 0.2f))
                Spacer(modifier = Modifier.height(14.dp))

                // Section 2: Audio Voice
                SettingsSectionHeader(
                    icon = Icons.Default.RecordVoiceOver,
                    title = "Suara dan Google TTS"
                )

                Spacer(modifier = Modifier.height(10.dp))

                // Auto Speak Toggle
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(14.dp))
                        .background(Color(0xFF181818))
                        .padding(12.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column(modifier = Modifier.weight(1f)) {
                        Text("Auto-Read Suara", fontWeight = FontWeight.SemiBold, fontSize = 14.sp, color = Color.White)
                        Text("Bacakan jawaban AI secara otomatis setelah merespon", fontSize = 11.sp, color = TextSecondary)
                    }
                    Switch(
                        checked = autoSpeak,
                        onCheckedChange = { onAutoSpeakChange() },
                        colors = SwitchDefaults.colors(
                            checkedThumbColor = PureBlack,
                            checkedTrackColor = Color.White,
                            uncheckedThumbColor = Color.LightGray,
                            uncheckedTrackColor = Color(0xFF333333)
                        )
                    )
                }

                Spacer(modifier = Modifier.height(12.dp))

                // TTS Speed Slider
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(14.dp))
                        .background(Color(0xFF181818))
                        .padding(12.dp)
                ) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Text("Kecepatan Suara", fontSize = 13.sp, color = Color.White)
                        Text("${String.format("%.1f", speechRate)}x", fontSize = 13.sp, fontWeight = FontWeight.Bold, color = Color.White)
                    }
                    Slider(
                        value = speechRate,
                        onValueChange = onSpeechRateChange,
                        valueRange = 0.5f..2.0f,
                        colors = SliderDefaults.colors(
                            thumbColor = Color.White,
                            activeTrackColor = Color.White,
                            inactiveTrackColor = Color(0xFF444444)
                        )
                    )
                }

                Spacer(modifier = Modifier.height(8.dp))

                // TTS Pitch Slider
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(14.dp))
                        .background(Color(0xFF181818))
                        .padding(12.dp)
                ) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Text("Nada Pitch Suara", fontSize = 13.sp, color = Color.White)
                        Text("${String.format("%.1f", pitch)}x", fontSize = 13.sp, fontWeight = FontWeight.Bold, color = Color.White)
                    }
                    Slider(
                        value = pitch,
                        onValueChange = onPitchChange,
                        valueRange = 0.5f..1.5f,
                        colors = SliderDefaults.colors(
                            thumbColor = Color.White,
                            activeTrackColor = Color.White,
                            inactiveTrackColor = Color(0xFF444444)
                        )
                    )
                }

                Spacer(modifier = Modifier.height(18.dp))
                HorizontalDivider(color = Color.White.copy(alpha = 0.2f))
                Spacer(modifier = Modifier.height(14.dp))

                // Section 3: Admin Contacts
                SettingsSectionHeader(
                    icon = Icons.Default.Info,
                    title = "Informasi Admin Resmi"
                )

                Spacer(modifier = Modifier.height(10.dp))

                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(14.dp))
                        .background(Color(0xFF181818))
                        .padding(12.dp)
                ) {
                    Text("RAY-CHAT AI Engine", fontWeight = FontWeight.Bold, fontSize = 14.sp, color = Color.White)
                    Text("Diperkuat Gemini Flash Realtime DDG Scraper dan Google TTS", fontSize = 12.sp, color = TextSecondary)
                }

                Spacer(modifier = Modifier.height(10.dp))

                // WhatsApp Admin Button with Logo
                AdminSocialButton(
                    logo = { WhatsAppLogo(modifier = Modifier.size(22.dp)) },
                    label = "WhatsApp Admin",
                    onClick = {
                        val intent = Intent(Intent.ACTION_VIEW, Uri.parse("https://whatsapp.com/channel/0029Vb89VkwLNSZyIqpdbX3t"))
                        context.startActivity(intent)
                    }
                )

                Spacer(modifier = Modifier.height(8.dp))

                // TikTok Admin Button with Logo
                AdminSocialButton(
                    logo = { TikTokLogo(modifier = Modifier.size(22.dp)) },
                    label = "TikTok Admin",
                    onClick = {
                        val intent = Intent(Intent.ACTION_VIEW, Uri.parse("https://www.tiktok.com/@rayytampann"))
                        context.startActivity(intent)
                    }
                )
            }
        },
        confirmButton = {
            Button(
                onClick = onDismiss,
                colors = ButtonDefaults.buttonColors(
                    containerColor = Color.White,
                    contentColor = PureBlack
                ),
                shape = RoundedCornerShape(20.dp),
                modifier = Modifier
                    .fillMaxWidth()
                    .height(48.dp)
                    .testTag("close_settings_button")
            ) {
                Text("Simpan dan Selesai", fontWeight = FontWeight.Bold, fontSize = 15.sp)
            }
        },
        containerColor = Color(0xFF0A0A0A),
        shape = RoundedCornerShape(24.dp),
        modifier = Modifier.border(1.dp, Color.White.copy(alpha = 0.25f), RoundedCornerShape(24.dp))
    )
}

@Composable
private fun SettingsSectionHeader(
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    title: String
) {
    Row(verticalAlignment = Alignment.CenterVertically) {
        Icon(
            imageVector = icon,
            contentDescription = title,
            tint = Color.White,
            modifier = Modifier.size(20.dp)
        )
        Spacer(modifier = Modifier.width(8.dp))
        Text(
            text = title,
            fontWeight = FontWeight.Bold,
            fontSize = 15.sp,
            color = Color.White
        )
    }
}

@Composable
private fun PersonaOptionCard(
    title: String,
    description: String,
    isSelected: Boolean,
    onClick: () -> Unit
) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(14.dp))
            .background(if (isSelected) Color(0xFF222222) else Color(0xFF141414))
            .border(
                width = 1.dp,
                color = if (isSelected) Color.White else Color.White.copy(alpha = 0.15f),
                shape = RoundedCornerShape(14.dp)
            )
            .clickable { onClick() }
            .padding(12.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        RadioButton(
            selected = isSelected,
            onClick = onClick,
            colors = RadioButtonDefaults.colors(
                selectedColor = Color.White,
                unselectedColor = Color.Gray
            )
        )
        Spacer(modifier = Modifier.width(8.dp))
        Column(modifier = Modifier.weight(1f)) {
            Text(title, fontWeight = FontWeight.Bold, fontSize = 14.sp, color = Color.White)
            Spacer(modifier = Modifier.height(2.dp))
            Text(description, fontSize = 11.sp, color = TextSecondary, lineHeight = 15.sp)
        }
    }
}

@Composable
private fun AdminSocialButton(
    logo: @Composable () -> Unit,
    label: String,
    onClick: () -> Unit
) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(14.dp))
            .background(Color.Black)
            .border(1.dp, Color.White.copy(alpha = 0.3f), RoundedCornerShape(14.dp))
            .clickable { onClick() }
            .padding(horizontal = 16.dp, vertical = 12.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.SpaceBetween
    ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            logo()
            Spacer(modifier = Modifier.width(12.dp))
            Text(
                text = label,
                fontWeight = FontWeight.Bold,
                fontSize = 14.sp,
                color = Color.White
            )
        }
        Icon(
            imageVector = Icons.Default.OpenInNew,
            contentDescription = "Buka Link",
            tint = Color.White,
            modifier = Modifier.size(18.dp)
        )
    }
}

@Composable
fun ResetConfirmDialog(
    onConfirmReset: () -> Unit,
    onDismiss: () -> Unit
) {
    AlertDialog(
        onDismissRequest = onDismiss,
        title = {
            Text(
                text = "Hapus Pembicaraan Ini",
                style = MaterialTheme.typography.titleLarge,
                color = Color.White,
                fontWeight = FontWeight.Bold
            )
        },
        text = {
            Text(
                text = "Apakah Anda yakin ingin menghapus seluruh pesan pada sesi obrolan ini? Tindakan ini tidak dapat dibatalkan.",
                style = MaterialTheme.typography.bodyMedium,
                color = TextSecondary
            )
        },
        confirmButton = {
            Button(
                onClick = onConfirmReset,
                colors = ButtonDefaults.buttonColors(containerColor = Color.White, contentColor = PureBlack),
                shape = RoundedCornerShape(16.dp),
                modifier = Modifier.testTag("confirm_reset_button")
            ) {
                Text("Hapus Sekarang", fontWeight = FontWeight.Bold)
            }
        },
        dismissButton = {
            OutlinedButton(
                onClick = onDismiss,
                shape = RoundedCornerShape(16.dp),
                border = androidx.compose.foundation.BorderStroke(1.dp, Color.White.copy(alpha = 0.3f)),
                modifier = Modifier.testTag("cancel_reset_button")
            ) {
                Text("Batal", color = Color.White)
            }
        },
        containerColor = Color(0xFF0A0A0A),
        shape = RoundedCornerShape(20.dp),
        modifier = Modifier.border(1.dp, Color.White.copy(alpha = 0.25f), RoundedCornerShape(20.dp))
    )
}
