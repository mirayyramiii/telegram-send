package com.example.ui.components

import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.scale
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.theme.DarkPillBg
import com.example.ui.theme.ElectricViolet
import com.example.ui.theme.LiveOrbStart
import com.example.ui.theme.TextPrimary
import com.example.ui.theme.TextSecondary
import kotlinx.coroutines.delay

@Composable
fun AiRespondingAnimation(
    modifier: Modifier = Modifier
) {
    val infiniteTransition = rememberInfiniteTransition(label = "ai_thinking")

    val pulseScale by infiniteTransition.animateFloat(
        initialValue = 0.8f,
        targetValue = 1.2f,
        animationSpec = infiniteRepeatable(
            animation = tween(800, easing = LinearEasing),
            repeatMode = RepeatMode.Reverse
        ),
        label = "pulse_scale"
    )

    Column(
        modifier = modifier
            .fillMaxWidth()
            .padding(vertical = 12.dp, horizontal = 16.dp)
    ) {
        Row(
            verticalAlignment = Alignment.CenterVertically,
            modifier = Modifier
                .clip(RoundedCornerShape(20.dp))
                .background(DarkPillBg)
                .padding(horizontal = 16.dp, vertical = 10.dp)
        ) {
            // Glowing Orb Icon
            Box(
                modifier = Modifier
                    .size(24.dp)
                    .scale(pulseScale)
                    .clip(CircleShape)
                    .background(
                        Brush.linearGradient(
                            listOf(LiveOrbStart, ElectricViolet)
                        )
                    )
            )

            Spacer(modifier = Modifier.width(12.dp))

            Text(
                text = "RAY-CHAT sedang berpikir...",
                style = MaterialTheme.typography.bodyMedium,
                fontWeight = FontWeight.Medium,
                color = TextPrimary,
                fontSize = 14.sp
            )

            Spacer(modifier = Modifier.width(12.dp))

            // 3 Animated Typing Dots
            Row(
                horizontalArrangement = Arrangement.spacedBy(4.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                val dots = listOf(
                    remember { Animatable(0.3f) },
                    remember { Animatable(0.3f) },
                    remember { Animatable(0.3f) }
                )

                dots.forEachIndexed { index, animatable ->
                    LaunchedEffect(animatable) {
                        delay(index * 200L)
                        while (true) {
                            animatable.animateTo(
                                targetValue = 1.0f,
                                animationSpec = tween(400)
                            )
                            animatable.animateTo(
                                targetValue = 0.3f,
                                animationSpec = tween(400)
                            )
                        }
                    }

                    Box(
                        modifier = Modifier
                            .size(7.dp)
                            .scale(animatable.value)
                            .clip(CircleShape)
                            .background(LiveOrbStart.copy(alpha = animatable.value))
                    )
                }
            }
        }
    }
}
