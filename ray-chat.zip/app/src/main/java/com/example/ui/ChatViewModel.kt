package com.example.ui

import android.app.Application
import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.widget.Toast
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.AppDatabase
import com.example.data.ChatMessageEntity
import com.example.data.ChatRepository
import com.example.engine.EngineStatus
import com.example.engine.RayEngine
import com.example.notification.RealtimeNotificationManager
import com.example.voice.TtsManager
import com.example.voice.VoiceRecognizerManager
import kotlinx.coroutines.ExperimentalCoroutinesApi
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.flatMapLatest
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch
import java.util.UUID

@OptIn(ExperimentalCoroutinesApi::class)
class ChatViewModel(application: Application) : AndroidViewModel(application) {

    private val repository: ChatRepository
    val ttsManager: TtsManager
    val voiceRecognizerManager: VoiceRecognizerManager
    private val notificationManager: RealtimeNotificationManager

    val currentSessionId = MutableStateFlow("session_default")

    val messages: StateFlow<List<ChatMessageEntity>>
    val allSessions: StateFlow<List<String>>

    private val _isLiveVoiceMode = MutableStateFlow(false)
    val isLiveVoiceMode: StateFlow<Boolean> = _isLiveVoiceMode.asStateFlow()

    private val _isProcessing = MutableStateFlow(false)
    val isProcessing: StateFlow<Boolean> = _isProcessing.asStateFlow()

    private val _selectedPersona = MutableStateFlow("rudi") // "rudi" or "ray"
    val selectedPersona: StateFlow<String> = _selectedPersona.asStateFlow()

    private val _autoSpeakTts = MutableStateFlow(true)
    val autoSpeakTts: StateFlow<Boolean> = _autoSpeakTts.asStateFlow()

    private val _notificationsEnabled = MutableStateFlow(true)
    val notificationsEnabled: StateFlow<Boolean> = _notificationsEnabled.asStateFlow()

    private val _showSettingsDialog = MutableStateFlow(false)
    val showSettingsDialog: StateFlow<Boolean> = _showSettingsDialog.asStateFlow()

    private val _showResetDialog = MutableStateFlow(false)
    val showResetDialog: StateFlow<Boolean> = _showResetDialog.asStateFlow()

    init {
        val database = AppDatabase.getInstance(application)
        repository = ChatRepository(database.chatDao())
        ttsManager = TtsManager(application)
        voiceRecognizerManager = VoiceRecognizerManager(application)
        notificationManager = RealtimeNotificationManager(application)

        messages = currentSessionId
            .flatMapLatest { sessionId ->
                repository.getMessages(sessionId)
            }
            .stateIn(
                scope = viewModelScope,
                started = SharingStarted.WhileSubscribed(5000),
                initialValue = emptyList()
            )

        allSessions = repository.getAllSessions()
            .stateIn(
                scope = viewModelScope,
                started = SharingStarted.WhileSubscribed(5000),
                initialValue = listOf("session_default")
            )

        // Seed initial greeting message if database is empty
        viewModelScope.launch {
            if (repository.getCount(currentSessionId.value) == 0) {
                repository.addMessage(
                    ChatMessageEntity(
                        sessionId = currentSessionId.value,
                        sender = "assistant",
                        content = "Mari kita mulai, RAY-CHAT.",
                        persona = "rudi"
                    )
                )
            }
        }
    }

    fun toggleLiveVoiceMode() {
        _isLiveVoiceMode.value = !_isLiveVoiceMode.value
        if (_isLiveVoiceMode.value) {
            // Start listening automatically when entering live voice mode
            startLiveVoiceListening()
        } else {
            voiceRecognizerManager.stopListening()
            ttsManager.stop()
        }
    }

    fun startLiveVoiceListening() {
        ttsManager.stop()
        voiceRecognizerManager.startListening { spokenText ->
            if (spokenText.isNotBlank()) {
                sendMessage(spokenText)
            }
        }
    }

    fun startVoiceInput(onTextRecognized: (String) -> Unit) {
        ttsManager.stop()
        voiceRecognizerManager.startListening { spokenText ->
            if (spokenText.isNotBlank()) {
                onTextRecognized(spokenText)
                sendMessage(spokenText)
            }
        }
    }

    fun createNewSession() {
        val newId = "session_${System.currentTimeMillis()}"
        currentSessionId.value = newId
        viewModelScope.launch {
            repository.addMessage(
                ChatMessageEntity(
                    sessionId = newId,
                    sender = "assistant",
                    content = "Percakapan baru dimulai.",
                    persona = _selectedPersona.value
                )
            )
        }
    }

    fun selectSession(sessionId: String) {
        currentSessionId.value = sessionId
    }

    fun sendMessage(userText: String) {
        if (userText.isBlank() || _isProcessing.value) return

        val textToProcess = userText.trim()
        val session = currentSessionId.value
        val persona = _selectedPersona.value

        // Immediately set isProcessing to prevent double send / race condition
        _isProcessing.value = true

        // Construct history items from current session messages for conversation memory
        val historyItems = messages.value
            .filter { !it.isError && it.content.isNotBlank() }
            .filter { 
                !it.content.startsWith("Mari kita mulai") && 
                !it.content.startsWith("Percakapan baru") && 
                !it.content.startsWith("🔄 Sesi Direset") 
            }
            .map { msg ->
                com.example.engine.ChatHistoryItem(
                    role = if (msg.sender == "user") "user" else "assistant",
                    content = msg.content
                )
            }

        viewModelScope.launch {
            try {
                // Save User Message
                repository.addMessage(
                    ChatMessageEntity(
                        sessionId = session,
                        sender = "user",
                        content = textToProcess,
                        persona = persona
                    )
                )

                // Execute CPU Scraper Pipeline with session context memory
                RayEngine.processQuery(
                    query = textToProcess,
                    persona = persona,
                    sessionUuid = session,
                    history = historyItems
                ).collect { status ->
                    when (status) {
                        is EngineStatus.Progress -> {
                            // Background CPU scraping
                        }
                        is EngineStatus.Success -> {
                            _isProcessing.value = false

                            // Save Assistant Response
                            val aiMsg = ChatMessageEntity(
                                sessionId = session,
                                sender = "assistant",
                                content = status.responseText,
                                searchContext = status.searchContext,
                                persona = persona
                            )
                            repository.addMessage(aiMsg)

                            // Realtime Notification
                            if (_notificationsEnabled.value) {
                                notificationManager.showNotification(
                                    title = "RAY-CHAT",
                                    message = status.responseText.take(100)
                                )
                            }

                            // Auto Speak Google TTS if enabled or in live voice mode
                            if (_autoSpeakTts.value || _isLiveVoiceMode.value) {
                                ttsManager.speak(status.responseText)
                            }
                        }
                        is EngineStatus.Error -> {
                            _isProcessing.value = false

                            repository.addMessage(
                                ChatMessageEntity(
                                    sessionId = session,
                                    sender = "assistant",
                                    content = "Error: ${status.message}",
                                    isError = true,
                                    persona = persona
                                )
                            )
                        }
                    }
                }
            } catch (e: Exception) {
                _isProcessing.value = false
            }
        }
    }

    fun resetChat() {
        viewModelScope.launch {
            repository.clearSession(currentSessionId.value)
            ttsManager.stop()
            _showResetDialog.value = false

            // Re-seed welcome message
            repository.addMessage(
                ChatMessageEntity(
                    sessionId = currentSessionId.value,
                    sender = "assistant",
                    content = "🔄 Sesi Direset! Sesi chat baru dimulai. CPU Scraper Engine siap menerima perintah.",
                    persona = _selectedPersona.value
                )
            )

            if (_notificationsEnabled.value) {
                notificationManager.showNotification(
                    title = "RAY-CHAT",
                    message = "Sesi chat telah direset."
                )
            }
        }
    }

    fun deleteSession(sessionId: String) {
        viewModelScope.launch {
            repository.clearSession(sessionId)
            if (currentSessionId.value == sessionId) {
                val remaining = allSessions.value.filter { it != sessionId }
                if (remaining.isNotEmpty()) {
                    currentSessionId.value = remaining.first()
                } else {
                    createNewSession()
                }
            }
        }
    }

    fun setPersona(persona: String) {
        _selectedPersona.value = persona
    }

    fun toggleAutoSpeak() {
        _autoSpeakTts.value = !_autoSpeakTts.value
    }

    fun toggleNotifications() {
        _notificationsEnabled.value = !_notificationsEnabled.value
    }

    fun toggleSettingsDialog(show: Boolean) {
        _showSettingsDialog.value = show
    }

    fun toggleResetDialog(show: Boolean) {
        _showResetDialog.value = show
    }

    fun speakText(text: String) {
        ttsManager.speak(text)
    }

    fun stopSpeaking() {
        ttsManager.stop()
    }

    fun copyToClipboard(text: String) {
        val clipboard = getApplication<Application>().getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
        val clip = ClipData.newPlainText("RAY-CHAT Code", text)
        clipboard.setPrimaryClip(clip)
        Toast.makeText(getApplication(), "Teks/Kode berhasil disalin!", Toast.LENGTH_SHORT).show()
    }

    override fun onCleared() {
        super.onCleared()
        ttsManager.shutdown()
        voiceRecognizerManager.stopListening()
    }
}
