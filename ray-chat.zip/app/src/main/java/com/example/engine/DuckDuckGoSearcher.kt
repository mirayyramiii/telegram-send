package com.example.engine

import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.OkHttpClient
import okhttp3.Request
import java.net.URLEncoder
import java.util.concurrent.TimeUnit
import java.util.regex.Pattern

object DuckDuckGoSearcher {

    private val client = OkHttpClient.Builder()
        .connectTimeout(3, TimeUnit.SECONDS)
        .readTimeout(3, TimeUnit.SECONDS)
        .followRedirects(true)
        .build()

    suspend fun searchRealtime(query: String): String = withContext(Dispatchers.IO) {
        try {
            val encoded = URLEncoder.encode(query, "UTF-8")
            val url = "https://lite.duckduckgo.com/lite/?q=$encoded"

            val request = Request.Builder()
                .url(url)
                .header("User-Agent", "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36")
                .header("Accept", "text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8")
                .header("Accept-Language", "id-ID,id;q=0.9,en;q=0.8")
                .build()

            val response = client.newCall(request).execute()
            if (!response.isSuccessful) return@withContext ""

            val html = response.body?.string() ?: return@withContext ""
            val results = mutableListOf<String>()

            // Simple regex match for duckduckgo lite snippets
            val snippetPattern = Pattern.compile("<td[^>]*class=\"result-snippet\"[^>]*>([\\s\\S]*?)</td>", Pattern.CASE_INSENSITIVE)
            val matcher = snippetPattern.matcher(html)

            while (matcher.find() && results.size < 4) {
                val raw = matcher.group(1) ?: ""
                val clean = raw.replace(Regex("<[^>]*>"), " ")
                    .replace(Regex("&quot;"), "\"")
                    .replace(Regex("&amp;"), "&")
                    .replace(Regex("&lt;"), "<")
                    .replace(Regex("&gt;"), ">")
                    .replace(Regex("\\s+"), " ")
                    .trim()

                if (clean.isNotBlank()) {
                    results.add(clean)
                }
            }

            if (results.isNotEmpty()) {
                results.joinToString("\n• ")
            } else {
                ""
            }
        } catch (e: Exception) {
            ""
        }
    }
}
