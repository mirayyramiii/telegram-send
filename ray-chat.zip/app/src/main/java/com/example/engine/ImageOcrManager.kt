package com.example.engine

import android.content.Context
import android.net.Uri
import com.google.mlkit.vision.common.InputImage
import com.google.mlkit.vision.text.TextRecognition
import com.google.mlkit.vision.text.latin.TextRecognizerOptions
import kotlinx.coroutines.suspendCancellableCoroutine
import kotlin.coroutines.resume

object ImageOcrManager {

    suspend fun recognizeTextFromUri(context: Context, imageUri: Uri): String = suspendCancellableCoroutine { continuation ->
        try {
            val image = InputImage.fromFilePath(context, imageUri)
            val recognizer = TextRecognition.getClient(TextRecognizerOptions.DEFAULT_OPTIONS)

            recognizer.process(image)
                .addOnSuccessListener { visionText ->
                    val extractedText = visionText.text.trim()
                    if (continuation.isActive) {
                        continuation.resume(if (extractedText.isNotBlank()) extractedText else "Tidak ada teks yang terdeteksi pada gambar ini.")
                    }
                }
                .addOnFailureListener { e ->
                    if (continuation.isActive) {
                        continuation.resume("Gagal melakukan OCR gambar: ${e.localizedMessage}")
                    }
                }
        } catch (e: Exception) {
            if (continuation.isActive) {
                continuation.resume("Kesalahan saat membuka file gambar: ${e.localizedMessage}")
            }
        }
    }
}
