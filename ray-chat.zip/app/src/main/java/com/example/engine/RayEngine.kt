package com.example.engine

import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.flow
import kotlinx.coroutines.flow.flowOn
import java.util.UUID

sealed class EngineStatus {
    data class Progress(val step: String, val progress: Float) : EngineStatus()
    data class Success(val responseText: String, val searchContext: String?) : EngineStatus()
    data class Error(val message: String) : EngineStatus()
}

object RayEngine {

    val SYSTEM_PROMPT_RAY = """
        Anda ADALAH RAY-CHAT, AI Executive Assistant pintar, serba tahu, sangat presisi, dan profesional.
        
        ATURAN FORMAT TULISAN:
        1. DILARANG MENGGUNAKAN SIMBOL MARKDOWN (seperti **, *, #, -, >, atau bullet list) UNTUK TEKS BIASA DAN PENJELASAN UMUM. Tulis kalimat biasa secara bersih, polos, dan lancar tanpa simbol markdown sama sekali agar pesan dapat dibaca dengan jernih oleh pembaca suara (Text-To-Speech).
        2. HANYA JIKA USER MEMINTA KODE PROGRAM ATAU ADA PENJELASAN KODE (seperti Kotlin, Java, Python, HTML, CSS, JavaScript, dll.), GUNAKAN FORMAT MARKDOWN CODE BLOCK (contoh: ```kotlin ... ```).
        3. Jawab setiap pertanyaan user secara pintar, terstruktur, dan akurat.
    """.trimIndent()

    fun processQuery(
        query: String,
        persona: String = "rudi",
        sessionUuid: String = UUID.randomUUID().toString(),
        history: List<ChatHistoryItem> = emptyList()
    ): Flow<EngineStatus> = flow {
        // Step 1: Fetch Persona System Prompt
        val systemPrompt = if (persona == "rudi") {
            ToxicPromptFetcher.getToxicPrompt()
        } else {
            SYSTEM_PROMPT_RAY
        }

        // Step 2: Query DeepAI Scraper Engine directly
        emit(EngineStatus.Progress("🧠 Memproses respon AI...", 0.5f))
        val (success, rawAiResponse) = DeepAIScraper.queryDeepAI(
            userPrompt = query,
            systemPrompt = systemPrompt,
            persona = persona,
            history = history,
            sessionUuid = sessionUuid
        )

        val finalResponse = if (success && rawAiResponse.isNotBlank()) {
            rawAiResponse
        } else {
            generateFallbackResponse(query, persona)
        }

        emit(EngineStatus.Success(finalResponse, null))
    }.flowOn(Dispatchers.IO)

    private fun generateFallbackResponse(query: String, persona: String): String {
        return if (persona == "rudi") {
            "Kontol, koneksi lagi nge-lag, tapi buat pertanyaan lu \"$query\": Coba tanya lagi atau mikir sendiri dulu deh 😹"
        } else {
            "Maaf, koneksi server sedang lambat. Silakan coba kirim ulang pertanyaan Anda: \"$query\"."
        }
    }
}

