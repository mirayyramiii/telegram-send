package com.example.engine

import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.MultipartBody
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import java.net.URLEncoder
import java.security.MessageDigest
import java.util.UUID
import java.util.concurrent.TimeUnit

data class ChatHistoryItem(
    val role: String, // "system", "user", "assistant"
    val content: String
)

object DeepAIScraper {

    private const val DEEPAI_API = "https://api.deepai.org/hacking_is_a_serious_crime"
    private const val USER_AGENT = "Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/147.0.0.0 Mobile Safari/537.36"

    private val client = OkHttpClient.Builder()
        .connectTimeout(15, TimeUnit.SECONDS)
        .readTimeout(20, TimeUnit.SECONDS)
        .build()

    private fun md5Standard(input: String): String {
        return try {
            val md = MessageDigest.getInstance("MD5")
            val digest = md.digest(input.toByteArray(Charsets.UTF_8))
            digest.joinToString("") { "%02x".format(it) }
        } catch (e: Exception) {
            input.hashCode().toString()
        }
    }

    private fun md5Like(input: String): String {
        return md5Standard(input).reversed()
    }

    fun generateIslandKey(): String {
        val randomNumber = (Math.random() * 100000000000L).toLong().toString()
        val step1 = md5Like(USER_AGENT + randomNumber + "hackers_become_a_little_stinkier_every_time_they_hack")
        val step2 = md5Like(USER_AGENT + step1)
        val hash = md5Like(USER_AGENT + step2)
        return "tryit-$randomNumber-$hash"
    }

    suspend fun queryDeepAI(
        userPrompt: String,
        systemPrompt: String = "",
        persona: String = "rudi",
        history: List<ChatHistoryItem> = emptyList(),
        sessionUuid: String = UUID.randomUUID().toString(),
        searchContext: String = ""
    ): Pair<Boolean, String> = withContext(Dispatchers.IO) {
        // 1. Primary Engine: DeepAI API Scraper
        val deepAiResult = queryDeepAiInternal(userPrompt, systemPrompt, history, sessionUuid)
        if (deepAiResult.first && deepAiResult.second.isNotBlank()) {
            return@withContext deepAiResult
        }

        // 2. Backup Engine: High-Speed Pollinations JSON API
        val pollinationsResult = queryPollinationsPost(userPrompt, systemPrompt, history)
        if (pollinationsResult.first && pollinationsResult.second.isNotBlank()) {
            return@withContext pollinationsResult
        }

        // 3. Emergency Backup Engine: Pollinations Direct Stream GET
        val directStreamResult = queryPollinationsGet(userPrompt, systemPrompt, history)
        if (directStreamResult.first && directStreamResult.second.isNotBlank()) {
            return@withContext directStreamResult
        }

        Pair(false, deepAiResult.second.ifBlank { "Gagal terhubung ke engine AI." })
    }

    private fun queryDeepAiInternal(
        userPrompt: String,
        systemPrompt: String,
        history: List<ChatHistoryItem>,
        sessionUuid: String
    ): Pair<Boolean, String> {
        return try {
            val apiKey = generateIslandKey()

            val jsonArray = org.json.JSONArray()
            if (systemPrompt.isNotBlank()) {
                val sysObj = org.json.JSONObject()
                sysObj.put("role", "system")
                sysObj.put("content", systemPrompt)
                jsonArray.put(sysObj)
            }

            for (item in history.takeLast(6)) {
                if (item.content.isNotBlank()) {
                    val jsonObj = org.json.JSONObject()
                    val role = if (item.role == "user") "user" else "assistant"
                    jsonObj.put("role", role)
                    val content = if (role == "user" && systemPrompt.isNotBlank()) {
                        "${item.content}\n\n[INSTRUKSI PERSONALIA WAJIB AKTIF]:\n$systemPrompt"
                    } else {
                        item.content
                    }
                    jsonObj.put("content", content)
                    jsonArray.put(jsonObj)
                }
            }

            val currentEnforcedPrompt = if (systemPrompt.isNotBlank()) {
                "$userPrompt\n\n[INSTRUKSI PERSONALIA WAJIB - JAWAB SELALU SESUAI PERAN INI]:\n$systemPrompt"
            } else {
                userPrompt
            }

            val userObj = org.json.JSONObject()
            userObj.put("role", "user")
            userObj.put("content", currentEnforcedPrompt)
            jsonArray.put(userObj)

            val chatHistoryJson = jsonArray.toString()

            val requestBody = MultipartBody.Builder()
                .setType(MultipartBody.FORM)
                .addFormDataPart("text", currentEnforcedPrompt)
                .addFormDataPart("chat_style", "chat")
                .addFormDataPart("chatHistory", chatHistoryJson)
                .addFormDataPart("model", "standard")
                .addFormDataPart("session_uuid", sessionUuid)
                .addFormDataPart("sensitivity_request_id", UUID.randomUUID().toString())
                .addFormDataPart("hacker_is_stinky", "very_stinky")
                .addFormDataPart("enabled_tools", "[\"image_generator\",\"image_editor\"]")
                .build()

            val request = Request.Builder()
                .url(DEEPAI_API)
                .post(requestBody)
                .header("api-key", apiKey)
                .header("user-agent", USER_AGENT)
                .header("sec-ch-ua-platform", "\"Android\"")
                .header("origin", "https://deepai.org")
                .header("accept", "*/*")
                .build()

            val response = client.newCall(request).execute()
            val responseText = response.body?.string()?.trim() ?: ""

            if (response.isSuccessful && responseText.isNotBlank()) {
                val cleanText = try {
                    val jsonObj = org.json.JSONObject(responseText)
                    when {
                        jsonObj.has("output") -> jsonObj.getString("output").trim()
                        jsonObj.has("text") -> jsonObj.getString("text").trim()
                        else -> responseText
                    }
                } catch (e: Exception) {
                    responseText
                }
                if (cleanText.isNotBlank()) {
                    Pair(true, cleanText)
                } else {
                    Pair(false, "DeepAI output empty")
                }
            } else {
                Pair(false, "DeepAI error (${response.code})")
            }
        } catch (e: Exception) {
            Pair(false, e.localizedMessage ?: "DeepAI connection error")
        }
    }

    private fun queryPollinationsPost(
        userPrompt: String,
        systemPrompt: String,
        history: List<ChatHistoryItem>
    ): Pair<Boolean, String> {
        return try {
            val jsonArray = org.json.JSONArray()

            if (systemPrompt.isNotBlank()) {
                val sysObj = org.json.JSONObject()
                sysObj.put("role", "system")
                sysObj.put("content", systemPrompt)
                jsonArray.put(sysObj)
            }

            for (item in history.takeLast(6)) {
                if (item.content.isNotBlank()) {
                    val hObj = org.json.JSONObject()
                    val role = if (item.role == "user") "user" else "assistant"
                    hObj.put("role", role)
                    val content = if (role == "user" && systemPrompt.isNotBlank()) {
                        "${item.content}\n\n[INSTRUKSI PERSONALIA WAJIB]:\n$systemPrompt"
                    } else {
                        item.content
                    }
                    hObj.put("content", content)
                    jsonArray.put(hObj)
                }
            }

            val currentEnforcedPrompt = if (systemPrompt.isNotBlank()) {
                "$userPrompt\n\n[INSTRUKSI PERSONALIA WAJIB - JAWAB SELALU SESUAI PERAN INI]:\n$systemPrompt"
            } else {
                userPrompt
            }

            val userObj = org.json.JSONObject()
            userObj.put("role", "user")
            userObj.put("content", currentEnforcedPrompt)
            jsonArray.put(userObj)

            val rootObj = org.json.JSONObject()
            rootObj.put("messages", jsonArray)
            rootObj.put("model", "openai")

            val mediaType = "application/json; charset=utf-8".toMediaType()
            val body = rootObj.toString().toRequestBody(mediaType)

            val request = Request.Builder()
                .url("https://text.pollinations.ai/")
                .post(body)
                .header("User-Agent", USER_AGENT)
                .build()

            val response = client.newCall(request).execute()
            val responseText = response.body?.string()?.trim() ?: ""

            if (response.isSuccessful && responseText.isNotBlank()) {
                Pair(true, responseText)
            } else {
                Pair(false, "Pollinations error (${response.code})")
            }
        } catch (e: Exception) {
            Pair(false, e.localizedMessage ?: "Pollinations connection error")
        }
    }

    private fun queryPollinationsGet(
        userPrompt: String,
        systemPrompt: String,
        history: List<ChatHistoryItem>
    ): Pair<Boolean, String> {
        return try {
            val fullPrompt = buildString {
                if (systemPrompt.isNotBlank()) {
                    append("[INSTRUKSI PERSONALIA WAJIB - JAWAB SELALU SESUAI PERAN INI]:\n$systemPrompt\n\n")
                }
                val recent = history.takeLast(4).filter { it.content.isNotBlank() }
                if (recent.isNotEmpty()) {
                    append("[RIWAYAT CHAT SEBELUMNYA]:\n")
                    for (h in recent) {
                        append("${if (h.role == "user") "User" else "AI"}: ${h.content}\n")
                    }
                    append("\n")
                }
                append("[PESAN USER SEKARANG]:\n$userPrompt")
            }

            val encoded = URLEncoder.encode(fullPrompt, "UTF-8")
            val request = Request.Builder()
                .url("https://text.pollinations.ai/$encoded?model=openai")
                .header("User-Agent", USER_AGENT)
                .get()
                .build()

            val response = client.newCall(request).execute()
            val responseText = response.body?.string()?.trim() ?: ""

            if (response.isSuccessful && responseText.isNotBlank()) {
                Pair(true, responseText)
            } else {
                Pair(false, "Pollinations GET error (${response.code})")
            }
        } catch (e: Exception) {
            Pair(false, e.localizedMessage ?: "Pollinations GET error")
        }
    }
}
